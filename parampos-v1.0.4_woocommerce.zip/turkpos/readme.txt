# Param - # Param - Woocommerce Ödeme Yöntemi
Contributors: Param
Tags: parampos, param ödeme yöntemi, param kredi kartı ile ödeme, param ödeme sistemi, param ödeme yazılım, param woocommerce
Requires at least: 4.9
Tested up to: 5.7
Requires PHP: 5.6
Stable tag: 1.0.4
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

# Param - Woocommerce Ödeme Yöntemi
------------
* Api Dökümantasyonu https://dev.param.com.tr

# Gereksinimler
---------------
* Soap Modül sunucu yüklü durumda olmalıdır.
* Sunucu ip adresiniz Param Panel entegrasyon bilgilerim kısmına eklenmek zorundadır.

# Yükleme
---------------
* Zip dosyasını indirin.
* Wordpress admin panelinize giriş yapın.
* Eklentiler-> Ekle Yüklenti kısmına tıklayın.
* Üst kısımdan yeni ekle tuşuna basın ve zip dosyasını seçerek yükleyin.
* Eklentiyi etkinleştir tuşuna basın.
* WooCommerce -> Ayarlar -> Ödemeler kısmından param posu aktif edin ve yönet tuşuna basın.
* Param.com.tr'ye giriş yaparak entegrasyon bilgilerim kısmından gerekli bilgileri alın ve yapılandırma kısmına girin.
* Modulü kaydedin ve kapatın, ödeme sisteminiz başarı ile kuruldu.


