# Param - Prestashop Ödeme Yöntemi
------------
* Api Dökümantasyonu https://dev.param.com.tr



# Yükleme
---------------

* PrestaShop admin paneline giriş yapıyoruz.
* “ModÜller”e tıklıyoruz.
* “ModÜller”in altında açılan “Module Manager”a tıklıyoruz.
* “Açılan bölümdeki arama satırına “Param Pos” yazıyoruz.
* “Param Payments” dosyasını seçip, “Install Now” butonuna basıyoruz. YÜkledikten
  sonra “Aktif” ediyoruz.
* Param.com.tr adresine giriş yaparak entegrasyon bilgilerimizi alıyoruz.
* “Entegrasyon Bilgilerim” sayfasındaki bilgileri PrestaShop’ ta Param POS başvurusu
  altında bulunan “Param Settings” bölümüne yazıyoruz. Taksit seçenek opsiyonunu için
  “Enable Installment”a “Evet” diyoruz. Tüm bilgileri girdikten sonra “Kaydet” butonuna
  basıyoruz.
  
