# Param - Prestashop Ödeme Yöntemi
------------
* Api Dökümantasyonu https://dev.param.com.tr

# Gereksinimler
---------------
* Soap Modül sunucu yüklü durumda olmalıdır.
* Sunucu ip adresiniz Param Panel entegrasyon bilgilerim kısmına eklenmek zorundadır.

# Yükleme
---------------
* Zip dosyasını indirin.
* Prestashop admin panelinize giriş yapın.
* Moduller-> Module Manager'a tıklayın.
* Üst kısımdan bir modül yükle butonuna basın ve zip dosyasını seçerek yükleyin.
* Yapılandır tuşuna basın.
* Param.com.tr'ye giriş yaparak entegrasyon bilgilerim kısmından gerekli bilgileri alın ve yapılandırma kısmına girin.
* Modulü kaydedin ve kapatın, ödeme sisteminiz başarı ile kuruldu.


