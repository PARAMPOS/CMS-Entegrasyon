# Param - Opencart Ödeme Yöntemi
------------
* Api Dökümantasyonu https://dev.param.com.tr

# Gereksinimler
---------------
* Soap Modül sunucu yüklü durumda olmalıdır.
* Sunucu ip adresiniz Param Panel entegrasyon bilgilerim kısmına eklenmek zorundadır.

# Yükleme
---------------
* Rar dosyasını indirin.
* Ftp panelinize giriş yaparak tüm dosyaları ana dizine upload edin.
* Admin panelinize giriş yapın.
* Eklentiler -> Eklentiler -> Ödeme Metodları kısmından param modulünü bulun ve aktif hale getirin.
* Düzenle botununa basarak gerekli entegrasyon bilgilerini girin ve modulü aktif hale getirin.


