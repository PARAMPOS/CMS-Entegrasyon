# Param - NopeCommerce Ödeme Yöntemi
------------
* Api Dökümantasyonu https://dev.param.com.tr



# Yükleme
---------------
* NopeCommerce Zip plugini indiriyoruz.
* Admin panele giriş yapıyoruz.
* Sol Menüden Yapılandırma -> Yerel eklentiler kısmına tıklıyoruz.
* Eklenti ve temayı yükle butonuna tıklıyoruz.
* Açılan upload ekranında dosya seç butonuna basıyoruz.
* Açılan ekrandan param pos modulunun olduğu zip dosyasını seçiyoruz. Eklenti veya temayı yükle
  butonuna tıklıyoruz.
* Eklenti listesinden param pos modulunun karşısındaki kur butonuna tıklıyoruz.
* Eklenti kurulduktan sonra restart application to apply changes butonuna tıklıyoruz (değişiklikleri
  kaydetmek için yenile).
* Sol Menüden Ödeme metodlarına tıklıyoruz.
* Payments param kısmının karşısındaki yapılandır butonuna tıklıyoruz.
* Param.com.tr üye girişi yaparak gerekli giriş bilgilerini alıp yapılandırma kısmındaki doğru alanlara
  bilgileri giriyoruz.
* Bilgileri girerek işlemi tamamlıyoruz.

