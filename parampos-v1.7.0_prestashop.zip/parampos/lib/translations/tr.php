<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{parampos}prestashop>parampos_accc2ffffba867cff868ccde3c30f212'] = 'Eklenti kurulurken bir hata oluştu.';
$_MODULE['<{parampos}prestashop>parampos_cdf6611c339c0f8f17b979d70a4f9210'] = 'Ayarlar';
$_MODULE['<{parampos}prestashop>parampos_f0aaaae189e9c7711931a65ffcd22543'] = 'Ödeme yöntemi';
$_MODULE['<{parampos}prestashop>parampos_bfa84a81490653cea604ae8b88007245'] = 'GUID boş bırakılamaz';
$_MODULE['<{parampos}prestashop>parampos_0da0a5ab420b2906c2c3c593d6d78647'] = 'Lütfen ödeme yöntemi seçiniz';
$_MODULE['<{parampos}prestashop>parampos_ba0c24b766a94a1cacf08a03d015e925'] = 'Kredi Kartı ile Ödeme';