/**
 * TURK Elektronik Para A.\u015e.
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "https://turkpos.com.tr/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.example;
