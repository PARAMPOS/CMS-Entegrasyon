# Param - WooCoommerce Ödeme Yöntemi
------------
* Api Dökümantasyonu https://dev.param.com.tr



# Yükleme
---------------
* Zip dosyasını indirin.
* Woocommerce Panelinizden eklentiler->yeni ekle kısmına basın.
* Üst kısımda bulunan eklenti yükle butonuna basarak zip dosyasını yükleyin.
* Plugini aktif hale getirin.
* Wocommerce -> ayarlar -> ödemeler kısmında gerekli entegrasyon bilgilerini girin ve kurulumu tamamlayın.
* <a href="https://dev.param.com.tr/tr/hazir-altyapi/woocommerce-plugin-kurulumu">Detaylı Kurulum Rehberi</a>

