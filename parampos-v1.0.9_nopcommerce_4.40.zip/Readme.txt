1. 'Nop.Plugin.Payments.Param' directory contains source code.
2. 'Payments.Param' contains binaries. Just drop it into \Plugins directory on your server.